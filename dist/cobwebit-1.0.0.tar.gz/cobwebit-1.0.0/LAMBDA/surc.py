import random as rd
import time as t
import string as str
import datetime
time = datetime.date
import colorama
from colorama import *
class Cobweb():
    def date():
        return time
    class messeges:
        def log(messege):
            print(Fore.LIGHTBLUE_EX + '[LOG] ' + messege)
        def warn(messege):
            print(Fore.YELLOW + '[WARN] ' + messege)
        def error(messege):
            print(Fore.LIGHTRED_EX + '[ERROR] ' + messege)
    class ascii_arts():
        def stickman():
            art = """
      O
     /|\\
     / \\
    /   \\
    """